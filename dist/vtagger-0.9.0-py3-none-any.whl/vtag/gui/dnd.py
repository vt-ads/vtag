from PyQt6.QtCore    import Qt
from PyQt6.QtWidgets import QLineEdit

class DnDLineEdit(QLineEdit):
    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls:
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls:
            event.setDropAction(Qt.CopyAction)
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        if event.mimeData().hasUrls:
            event.setDropAction(Qt.CopyAction)
            event.accept()
            text = ""
            for url in event.mimeData().urls():
                text = str(url.toLocalFile())
            self.setText(text)
        else:
            event.ignore()
